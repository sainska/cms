import React, { useState } from 'react';
//import bgImage from './CMS-LOGIN2.jpg';
import './Authpop.css';

//import { personOutline, mailOutline, lockClosedOutline } from 'ionicons/icons';

export default function AuthPopup() {
    const [isPopupActive, setIsPopupActive] = useState(false);
    const [isRegistering, setIsRegistering] = useState(false);

    const openPopup = () => setIsPopupActive(true);
    const closePopup = () => setIsPopupActive(false);

    const switchToRegister = () => setIsRegistering(true);
    const switchToLogin = () => setIsRegistering(false);

    return (
        <>
            <header>
                <div className="logo">CMS</div>
                <nav className="navigation">
                    <a href="#home">Home</a>
                    <a href="#about">About</a>
                    <button className="btnLogin-popup" onClick={openPopup}>Login</button>
                </nav>
            </header>

            {isPopupActive && (
                <div className={`wrapper ${isRegistering ? 'active' : ''}`} style={{ backgroundImage: `url(${bgImage})` }}>
                    <div className="popup-overlay">
                        <div className="auth-popup-wrapper">
                            <div className="form-box">
                                <div className="input-box">
                                    <input type="text" required />
                                    <label>Username</label>
                                </div>
                                <div className="input-box">
                                    <input type="password" required />
                                    <label>Password</label>
                                </div>
                                <div className="remember-forgot">
                                    <label><input type="checkbox" /> Remember me</label>
                                    <a href="#">Forgot Password?</a>
                                </div>
                                <button className="btn">Login</button>
                                <div className="login-register">
                                    <p>Don't have an account? <a href="#" onClick={(e) => { e.preventDefault(); switchToRegister(); }}>Register</a></p>
                                </div>
                            </div>

                            <div className="form-box">
                                <h2>Registration</h2>
                                <form action="#">
                                    <div className="input-box">
                                        <span className="icon"><IonIcon icon={personOutline} /></span>
                                        <input type="text" required />
                                        <label>Username</label>
                                    </div>
                                    <div className="input-box">
                                        <span className="icon"><IonIcon icon={mailOutline} /></span>
                                        <input type="email" required />
                                        <label>Email</label>
                                    </div>
                                    <div className="input-box">
                                        <span className="icon"><IonIcon icon={lockClosedOutline} /></span>
                                        <input type="password" required />
                                        <label>Password</label>
                                    </div>
                                    <div className="input-box">
                                        <span className="icon"><IonIcon icon={lockClosedOutline} /></span>
                                        <input type="password" required />
                                        <label>Confirm Password</label>
                                    </div>
                                    <div className="input-box">
                                        <input type="text" required />
                                        <label>Church Name</label>
                                    </div>
                                    <div className="input-box">
                                        <input type="number" required />
                                        <label>Age</label>
                                    </div>
                                    <div className="remember-forgot">
                                        <label><input type="checkbox" /> I agree to the terms & conditions</label>
                                    </div>
                                    <button className="btn1">Register</button>
                                    <div className="login-register">
                                        <p>Already have an account? <a href="#" onClick={(e) => { e.preventDefault(); switchToLogin(); }}>Login</a></p>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <footer>
                <p>© 2025 CMS App</p>
            </footer>
        </>
    );
}
