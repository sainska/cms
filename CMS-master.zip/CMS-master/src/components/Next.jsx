import { useState } from 'react';
import React from 'react';
import talk from '../images/talking.jpg';
import disc from '../images/discussion.jpeg';
import images from '../images/images.jpeg';
import './Next.css';

export default function Next() {
  return (
    <div className="page-container">
      <main className="main-section">
        <div className="hero">
          <h1>What next?</h1>
          <p>Explore the most common next steps below...</p>
           <div className="cards-container">
          <div className="card">
            <div className="card-image">
              <img src={talk} alt="Group of people talking and smiling" />
            </div>
            <div className="card-body">
              <h6>Catch up on Sunday message...</h6>
            </div>
          </div>
          <div className="card">
            <div className="card-image">
              <img src={disc} alt="Small group meeting" />
            </div>
            <div className="card-body">
            <h6>Find out more about who we are</h6>
            </div>
          </div>
          <div className="card">
            <div className="card-image">
              <img src={images} alt="Church community" />
            </div>
            <div className="card-body">
              <h6>Plan a visit to one of our</h6>
            </div>
          </div>
        </div>
        </div>
      </main>
    </div>
  );
}
