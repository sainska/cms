import React, { useState } from 'react';
import talk from '../images/talking.jpg';
import disc from '../images/discussion.jpeg';
import images from '../images/images.jpeg';
import './KnowUs.css';

export default function LivingRockChurch() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className="living-rock-container">
      <main className="main-content">
        <div className="hero-section">
          <div className="hero-text">
            <h2>Meet Living Rock Church</h2>
            <h1>Get to know us</h1>
            <p>
              Discover more about who we are, what we believe and how we function
            </p>
          </div>
        </div>

        <div className="cards-section">
          <div className="card">
            <div className="card-image">
              <img src={talk} alt="Church members engaging in friendly conversation" />
            </div>
            <div className="card-content">
              <h3>Where we're</h3>
              <p>Learn about our locations and service times.</p>
            </div>
          </div>

          <div className="card">
            <div className="card-image">
              <img src={disc} alt="Group Bible study during a weekly discussion session" />
            </div>
            <div className="card-content">
              <h3>What we believe</h3>
              <p>Explore our core values and beliefs.</p>
            </div>
          </div>

          <div className="card">
            <div className="card-image">
              <img src={images} alt="Congregation enjoying community service" />
            </div>
            <div className="card-content">
              <h3>How we serve</h3>
              <p>Discover ways to get involved and serve the community.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
