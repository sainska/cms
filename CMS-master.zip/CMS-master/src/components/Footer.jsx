// src/components/Footer.jsx
import './Footer.css';
import React from 'react';

const Footer = () => {
  return (
    <footer className="site-footer">
      <div className="footer-content">
        <div className="footer-logo">
          <h3>Living Rock Church</h3>
          <p>Standing firm in faith, grounded in love.</p>
        </div>
        <div className="footer-links">
          <a href="/">Home</a>
          <a href="/about">About Us</a>
          <a href="/media">Media</a>
          <a href="/contact">Contact Us</a>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} Living Rock Church. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;