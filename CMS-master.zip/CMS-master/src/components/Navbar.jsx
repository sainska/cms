import React, { useState } from 'react';
import './Navbar.css';
import logo from '../assets/logo_white.svg';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <nav className="navbar">
      <div className="navbar-top-banner">
        <p>
          <a href="#"> GET DIRECTIONS</a> OR <a href="/contact"> CONTACT US</a>.
        </p>
      </div>

      <div className="navbar-main">
        <img src={logo} alt="Living Rock Logo" className="navbar-logo" />

        <ul className={`navbar-links ${menuOpen ? 'open' : ''}`}>
          <li><a href="/">Home</a></li>
          <li><a href="/about">About Us</a></li>
          <li><a href="/events">Events </a></li>
          <li><a href="/media">Media </a></li>
          <li><a href="/contact">Contact Us </a></li>
          <li><a className="login" href="/login">LOGIN</a></li>
        </ul>
        <div className="menu-icon" onClick={toggleMenu}>
          <span>☰</span>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
