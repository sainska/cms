import React from 'react'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Contact from './pages/Contact-us'
import Login from './pages/Login'
import OurEvents from './pages/Our-Events'
import Aboutus from './pages/About-us'
import Media from './pages/Media'
import Register from './pages/Register'
import Navbar from './components/Navbar';
import Footer from './components/Footer'

function App() { 
  return (
    <><Navbar /><Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/events" element={<OurEvents />} />
        <Route path="/about" element={<Aboutus />} />
        <Route path="/media" element={<Media />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </Router>
    <Footer/></>
  )
  
}

export default App

