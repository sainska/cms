import React from 'react'
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import './Home.css';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
      
<section className="hero">
        <div className="hero-content">
          <h1>Welcome to Living Rock Church Kenya</h1>
          <p>We’re so glad you’re here.</p>
                  <div className="button-group">
          <Link to="/contact">
            <button>Meet Us</button>
          </Link>
        </div>
        </div>
      </section>

      <section className="intro">
        <h1>We're here to help you find your place</h1>
        <p>Explore who we are, what we believe, and how you can connect.</p>

        <div className='home-images'>
            <div className="gallery-images">
              <div className="image-container">
                <img src="../src/assets/church1.jpg" alt="Church 1" />
                <div className="overlay-text"><h2>We believe in growing together</h2></div>
              </div>
              <div className="image-container">
                <img src="../src/assets/church2.jpg" alt="Church 2" />
                <div className="overlay-text"><h2>We believe in helping each other</h2></div>
              </div>
              <div className="image-container">
                <img src="../src/assets/church3.jpg" alt="Church 3" />
                <div className="overlay-text"><h2>We believe in loving each other</h2></div>
              </div>
              <div className="image-container">
                <img src="../src/assets/church3.jpg" alt="Church 3" />
                <div className="overlay-text"><h2>We believe in loving each other</h2></div>
              </div>
              <div className="image-container">
                <img src="../src/assets/church3.jpg" alt="Church 3" />
                <div className="overlay-text"><h2>We believe in loving each other</h2></div>
              </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home

