import React from 'react';
import { Link } from 'react-router-dom';
import { User, Mail, Lock } from 'lucide-react'; // Lucide icons
import './Register.css';

const Register = ({ switchToLogin }) => {
  return (
    <div className="register-container">
      <div className="close-button">
        <Link to="/">&#x2715;</Link>
      </div>

      <div className="register-box">
        <h2 className="register-title">Create Account</h2>
        <form className="register-form">
          <div className="form-group">
            <span className="form-icon"><User size={20} /></span>
            <input type="text" required />
            <label>Username</label>
          </div>

          <div className="form-group">
            <span className="form-icon"><Mail size={20} /></span>
            <input type="email" required />
            <label>Email</label>
          </div>

          <div className="form-group">
            <span className="form-icon"><Lock size={20} /></span>
            <input type="password" required />
            <label>Password</label>
          </div>

          <div className="form-group">
            <span className="form-icon"><Lock size={20} /></span>
            <input type="password" required />
            <label>Confirm Password</label>
          </div>

          <div className="form-group">
            <input type="text" required />
            <label>Church Name</label>
          </div>

          <div className="form-group">
            <input type="number" required />
            <label>Age</label>
          </div>

          <div className="checkbox-group">
            <label>
              <input type="checkbox" /> I agree to the terms & conditions
            </label>
          </div>

          <button className="register-button">Register</button>

          <div className="login-redirect">
            <p>Already have an account? <a href="/login" onClick={switchToLogin}>Login</a></p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;
