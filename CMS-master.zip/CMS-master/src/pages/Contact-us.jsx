import React from "react";
import './Contact_us.css';

export default function ContactPage() {
  return (
    <div className="contact-page">

      <header className="header-section">
        <h1 className="header-title">Engage With Living Rock Church</h1>
        <p className="header-subtitle">We're excited to connect with you</p>
      </header>

      {/* Contact Form Section */}
      <section className="form-wrapper">
        <h2 className="form-title">Get in Touch</h2>
        <form className="contact-form">
          <div className="form-group">
            <input
              type="text"
              placeholder="Full Name"
              className="form-input"
            />
          </div>
          <div className="form-group">
            <input
              type="email"
              placeholder="Email Address"
              className="form-input"
            />
          </div>
          <div className="form-group">
            <input
              type="tel"
              placeholder="Phone Number"
              className="form-input"
            />
          </div>
          <div className="form-group">
            <input
              type="text"
              placeholder="Subject"
              className="form-input"
            />
          </div>
          <div className="form-group">
            <textarea
              placeholder="Message"
              rows="3"
              className="form-textarea"
            ></textarea>
          </div>
          <button type="submit" className="submit-button small-button">Submit</button>
        </form>

        {/* Social Media Icons */}
        <div className="social-icons">
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer"><i className="fab fa-facebook-f"></i></a>
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer"><i className="fab fa-instagram"></i></a>
          <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer"><i className="fab fa-tiktok"></i></a>
          <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer"><i className="fas fa-map-marker-alt"></i></a>
        </div>
      </section>

    </div>
  );
}
