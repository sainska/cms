import React, { useState } from "react";
import { X } from "lucide-react";
import media1 from '../images/media1.jpeg';
import media2 from '../images/media2.jpeg';
import media3 from '../images/media3.jpeg';
import './Media.css'; 

const sampleImages = [
  {
    id: 1,
    url: media1,
    caption: "Sunday Service - March 3rd, 2025",
  },
  {
    id: 2,
    url: media2,
    caption: "Youth Fellowship - March 10th, 2025",
  },
  {
    id: 3,
    url: media3,
    caption: "Easter Service - April 1st, 2025",
  },
];

const Media = () => {
  const [selectedImage, setSelectedImage] = useState(null);

  return (
    <div className="media-container">
      <h2 className="media-heading">Church Event Gallery</h2>

      <div className="media-grid">
        {sampleImages.map((img) => (
          <div
            key={img.id}
            className="media-card"
            onClick={() => setSelectedImage(img)}
          >
            <img src={img.url} alt={img.caption} className="media-image" />
            <div className="media-caption">{img.caption}</div>
          </div>
        ))}
      </div>

      {selectedImage && (
        <div className="media-modal-overlay" onClick={() => setSelectedImage(null)}>
          <div className="media-modal" onClick={(e) => e.stopPropagation()}>
            <button
              className="media-close-btn"
              onClick={() => setSelectedImage(null)}
            >
              <X size={24} />
            </button>
            <img
              src={selectedImage.url}
              alt={selectedImage.caption}
              className="media-modal-image"
            />
            <p className="media-modal-caption">{selectedImage.caption}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default Media;
