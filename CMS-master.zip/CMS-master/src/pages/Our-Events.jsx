import React from 'react';
import './Our-Events.css';

function Events() {
  return (
    <div>

      {/* Main content */}
      <main className="container">
        <h2>Upcoming Events</h2>
        <div className="event-grid">
          <div className="event-card">
            <img src="./images/media1.jpeg" alt="Worship Night" className="event-image" />
            <h3>Worship & Healing Night</h3>
            <div className="date">June 2, 2025</div>
            <div className="location">Nairobi Church Grounds</div>
            <p>Join us for a powerful evening of worship and prayer for healing.</p>
          </div>
          <div className="event-card">
            <img src="/images/youth-retreat.jpg" alt="Youth Retreat" className="event-image" />
            <h3>Youth Retreat</h3>
            <div className="date">June 15–17, 2025</div>
            <div className="location">Kisumu Christian Centre</div>
            <p>A weekend retreat for teens and young adults focused on faith and fun.</p>
          </div>
        </div>

        <h2>Past Events</h2>
        <div className="event-grid">
          <div className="event-card">
            <img src="/images/easter-celebration.jpg" alt="Easter Service" className="event-image" />
            <h3>Easter Celebration Service</h3>
            <div className="date">March 31, 2025</div>
            <div className="location">Eldoret Main Sanctuary</div>
            <p>A celebration of the resurrection of Christ with music, drama, and a special sermon.</p>
          </div>
          <div className="event-card">
            <img src="/images/community-outreach.jpg" alt="Community Outreach" className="event-image" />
            <h3>Community Outreach</h3>
            <div className="date">February 10, 2025</div>
            <div className="location">Nakuru Town Centre</div>
            <p>We reached out to families with food supplies and the message of hope.</p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer>
        &copy; 2025 Living Rock Church Kenya | <span className="gold">All for His Glory</span>
      </footer>
    </div>
  );
}
export default Events;
