import { useState } from 'react';
import React from 'react';
import LivingRockChurch from '../components/KnowUs';
import Next from '../components/Next';
import preacher from '../images/Preacher.jpg';
import logo from '../images/Church logo.jpeg';
import './About.css';

export default function NavBar() {
  
  return (
    <><div className="main-content">
      <div className="text-area">
        <h1 className="title">About Living Rock Church</h1>
        <p>
          Living Rock Church is a vibrant community of believers dedicated to spreading
          the love and teachings of Jesus Christ. Our mission is to transform lives
          through faith, hope, and love.
        </p>
        <p>
          With a rich history spanning several decades, we have grown into a
          multi-congregational church with locations across the UK. Our core values of
          worship, community, and service guide everything we do. Join us on this
          incredible journey of faith and discover the power of a life transformed by God's grace.
        </p>
      </div>
      <div className="image-area" style={{ backgroundImage: `url(${preacher})` }} />
    </div>
    <LivingRockChurch />
    <Next />
    </>
  );
}
