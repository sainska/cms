import React from 'react';
import './Login.css';

export default function Login({ switchToRegister }) {
    return (
        <div className="login-wrapper">
            <div className="form-box">
                <h2>Login</h2>
                <form className="form">
                    <div className="input-box">
                        <input type="text" required />
                        <label>Username</label>
                    </div>
                    <div className="input-box">
                        <input type="password" required />
                        <label>Password</label>
                    </div>
                    <div className="remember-forgot">
                        <label><input type="checkbox" /> Remember me</label>
                        <a href="#">Forgot Password?</a>
                    </div>
                    <button type="submit" className="btn">Login</button>
                    <div className="login-register">
                        <p>
                            Don't have an account? <a href="/register" onClick={switchToRegister}>Register</a>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    );
}
